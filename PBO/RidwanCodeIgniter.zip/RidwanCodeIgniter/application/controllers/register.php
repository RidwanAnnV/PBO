<?php
defined('BASEPATH') or exit('No direct script access allowed');

class register extends CI_Controller
{


	public function index()
	{
		$this->load->view('register');
	}
}